/*Take N numbers from the user as input, put them in an array and output the maximum and minimum of them.
For example, if user input is
25  14  78  5  90  67  32  85
then your program�s output is
Maximum = 90, Minimum = 5
*/
#include <stdio.h>

int main()
{
    int n;

    scanf("%d",&n);
    int arr[n];

    for(int i=0; i<n; i++)
    {
        scanf("%d",&arr[i]);
    }
int max=arr[0];
int min=arr[0];
    for(int i=0; i<n; i++)
    {
        if(arr[i]>max)
        {
            max=arr[i];
        }
        else if(arr[i]<min)
        {
            min=arr[i];
        }
    }

    printf("%d is max and %d is min",max,min);

}

