/*An array contains N numbers and we want to search any given number within the array.
For example, consider the following array
14  78  5  90  67  32  85
If we want to search 90, the output is �Found�
If we want to search 100, the output is �Not Found�
-*/
#include <stdio.h>

int main()
{
    int n,n1,found=0;
    ;

    scanf("%d",&n);
    int arr[n];

    for(int i=0; i<n; i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("Search: ");
    scanf("%d",&n1);

    for(int i=0; i<n; i++)
    {
        if(arr[i]== n1)
        {
            found=1;
            break;
        }
    }
    if(found== 1)
    {
        printf(" Found");

    }
    else
    {
        printf("Not Found");

    }

}
