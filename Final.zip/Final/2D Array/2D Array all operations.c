#include<stdio.h>

int main()
{
    int row,colum,arr[100][100];
    scanf("%d %d",&row,&colum);

    for(int i=0; i<row; i++)
    {
        for(int j=0; j<colum; j++)
        {
            printf("array[%d][%d]:",i,j);
            scanf("%d",&arr[i][j]);
        }
    }

    /*---print---*/
    for(int i=0; i<row; i++)
    {
        for(int j=0; j<colum; j++)
        {
            printf("%d ",arr[i][j]);
        }
        printf("\n");

    }

    /*-----addition---*/

    int row1,colum1,row2,colum2,arr1[100][100],arr2[100][100], arr3[100][100];
    scanf("%d %d",&row1,&colum1);
    scanf("%d %d",&row2,&colum2);

    if(row1!=row2 || colum1!=colum2)
    {
        printf("Invalid Dimention");
    }
    else
    {
        /*---1st matrix input------*/
        printf("1st array\n");

        for(int i=0; i<row1; i++)
        {
            for(int j=0; j<colum1; j++)
            {
                printf("array[%d][%d]:",i,j);
                scanf("%d",&arr1[i][j]);
            }
        }


        /*----2nd matrix---*/
        printf("2nd array");

        for(int i=0; i<row2; i++)
        {
            for(int j=0; j<colum2; j++)
            {
                printf("2nd array[%d][%d]:",i,j);
                scanf("%d",&arr2[i][j]);
            }
        }

        /*------addition----*/

        for(int i=0; i<row1; i++)
        {
            for(int j=0; j<colum1; j++)
            {
                arr3[i][j]=arr1[i][j]+arr2[i][j];
            }
        }
    }
    /*-----print addition ---*/

    for(int i=0; i<row1; i++)
    {
        for(int j=0; j<colum1; j++)
        {
            printf("%d ",arr3[i][j]);
        }
        printf("\n");
    }


    /*-------Multiply---*/

    int row3,colum3,row4,colum4,arr4[100][100],arr5[100][100],arr6[100][100];
    scanf("%d %d",&row3,&colum3);
    scanf("%d %d",&row4,&colum4);

    if(colum3!=row4)
    {
        printf("Invalid Dimention");

    }
    else
    {
        /*---1st matrix input------*/
        printf("1st array");

        for(int i=0; i<row3; i++)
        {
            for(int j=0; j<colum3; j++)
            {
                printf("array[%d][%d]:",i,j);
                scanf("%d",&arr4[i][j]);
            }
        }


        /*----2nd matrix---*/
        printf("2nd array");

        for(int i=0; i<row4; i++)
        {
            for(int j=0; j<colum4; j++)
            {
                printf("2nd array[%d][%d]:",i,j);
                scanf("%d",&arr5[i][j]);
            }
        }

        /*------ multiplikation---*/

        for(int i=0; i<row3; i++)
        {
            for(int j=0; j<colum4; j++)
            {
                arr6[i][j]=0;
                for(int k=0; k<colum3; k++)
                {
                    arr6[i][j]=arr6[i][j]+arr4[i][k]*arr5[k][j];

                }
            }
        }
    }
    /*----mul print-*/
    for(int i=0; i<row3; i++)
    {
        for(int j=0; j<colum4; j++)
        {
            printf("%d ",arr6[i][j]);
        }
        printf("\n");
    }


}
