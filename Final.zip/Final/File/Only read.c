#include<stdio.h>
#include<stdlib.h>
int main()
{
  char filename[100];
  char text[100];

  printf("Enter file name: ");
  gets(filename);

  FILE *file;
  file=fopen(filename,"w");

  if(file==NULL)
  {
      printf("Not open");
  }

  fgets(text,sizeof(text),stdin);

  fprintf(file,"%s",text);
 fclose(file);
  file=fopen(filename,"r");

  if(file==NULL)
  {
      printf("Not open");
  }

  while(fgets(text,sizeof(text),file)!=NULL)
  {
      printf("%s", text);
  }

  file=fopen(filename,"a");

  if(file==NULL)
  {
      printf("Not open");
  }

  fgets(text,sizeof(text),stdin);

  fprintf(file,"%s",text);
  fclose(file);


}
