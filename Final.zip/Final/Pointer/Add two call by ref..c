/*Write a program in C to add numbers using call by reference.*/
#include <stdio.h>

int callbyref(int *a,int*b)
{
    return *a+*b;
}
int main()
{
    int a,b,*ptr1,*ptr2,sum=0;
    scanf("%d",&a);
    scanf("%d",&b);

    sum=callbyref(&a,&b);

    printf("The sum of a and b is %d\n",sum);

    ptr1=&a;
    ptr2=&b;
    if(*ptr1>*ptr2)
    {
        printf("The number %d is bigger than %d.",*ptr1,*ptr2);
    }
    if(*ptr1<*ptr2)
    {
        printf("The number %d is smaller than %d.",*ptr1,*ptr2);
    }

    if(*ptr1==*ptr2)
    {
        printf("The number %d is equal to %d.",*ptr1,*ptr2);
    }

}
