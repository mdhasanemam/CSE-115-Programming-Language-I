#include <stdio.h>

int main()
{
    int x=10,p=3,q;

    int *ptr;
    ptr=&x;

    int *ptr2;
    ptr2=&p;

    printf("The value of x is %d. \n",x);
    printf("The value of x is %p. \n",&x);
    printf("The address of ptr is %p. \n",ptr);
    printf("The value of content is %d. \n",*ptr);
    printf("The address of ptr is %p. \n",ptr2);
    printf("The value of content is %d. \n",*ptr2);


    int m = 10, n, o;
    int *z = &m; // Declaring an integer pointer z and assigning the address of m to it

    // Printing basic information about pointers and variables
    printf("\n\n Pointer : Show the basic declaration of pointer :\n");
    printf("-------------------------------------------------------\n");
    printf(" Here is m=10, n and o are two integer variable and *z is an integer");
    printf("\n\n z stores the address of m  = %p\n", z); // Printing the address stored in z using %p
    printf("\n *z stores the value of m = %i\n", *z); // Printing the value pointed to by z using *z
    printf("\n &m is the address of m = %p\n", &m); // Printing the address of m using &m
    printf("\n &n stores the address of n = %p\n", &n); // Printing the address of n using &n
    printf("\n &o  stores the address of o = %p\n", &o); // Printing the address of o using &o
    printf("\n &z stores the address of z = %p\n\n", &z); // Printing the address of z using &z


}
