#include<stdio.h>
#include<stdlib.h>

int main()
{
    int n;
    int *ptr;

    scanf("%d",&n);

    ptr=(int *) malloc(n*sizeof(int));

    if(ptr==NULL)
    {
        printf("Not Allocated");
    }

    for(int i=0; i<n; i++)
    {
        printf("Element -%d \n",i+1);
        scanf("%d",ptr+i);
    }
    printf("\n");

    int max=*ptr;
    int min=*ptr;
    for(int i=0; i<n; i++)
    {
        if(*(ptr+i)>max)
        {
            max=*(ptr+i);
        }
        if(*(ptr+i)<min)
        {
            min=*(ptr+i);
        }
    }

    printf("The maximum number is %d and the the minimum number is %d.",max,min);

}
