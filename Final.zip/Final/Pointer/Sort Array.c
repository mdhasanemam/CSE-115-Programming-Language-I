
/*Write a program in C to swap elements using call by reference.*/

#include <stdio.h>

int main()
{
    int arr[100];
    int *ptr =arr;
    int size;
    scanf("%d",&size);

    for(int i=0;i<size;i++)
    {
        printf("Element - %d: \n",i+1);
        scanf("%d",ptr+i);
    }

  printf("Array: ");

  for(int i=0;i<size;i++)
    {
        printf("%d ",*(ptr+i));
    }


    for(int i=0;i<size;i++)
    {
        for(int j=i+1;j<size;j++)
        {
            int temp;
            if(*(ptr+i)>*(ptr+j))
            {
                temp=*(ptr+i);
                *(ptr+i)=*(ptr+j);
                *(ptr+j)=temp;
            }
        }
    }

     printf("\nSorted Array: ");

  for(int i=0;i<size;i++)
    {
        printf("%d ",*(ptr+i));
    }

    /*---reverse--*/
    printf("\nReverse Array: ");

     for(int i=size-1;i>=0;i--)
    {
        printf("%d ",*(ptr+i));
    }

 /*---sum--*/

 int sum=0;

 for(int i=0;i<size;i++)
    {
        sum=sum+*(ptr+i);
    }
  printf("\nThe sum is %d", sum);
}
