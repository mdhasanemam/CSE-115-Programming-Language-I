/*Write a program in C to add two numbers using pointers.*/

#include <stdio.h>

int main()
{
    int a,b,*ptr1,*ptr2,sum=0;

    scanf("%d",&a);
    scanf("%d",&b);

    ptr1=&a;
    ptr2=&b;

    sum=*ptr1+*ptr2;

    printf("The sum of a and b is %d ",sum);
}
