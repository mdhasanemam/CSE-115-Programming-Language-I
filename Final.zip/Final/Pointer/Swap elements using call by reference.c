/*Write a program in C to swap elements using call by reference.*/

#include <stdio.h>

int callbyrefswap(int *a,int*b, int *c)
{
    *c=*a;
    *a=*b;
    *b=*c;

    printf("After swap a=%d and b=%d",*a,*b);
}
int main()
{
    int a,b,c;
    scanf("%d",&a);
    scanf("%d",&b);
    printf("Before swap a=%d and b=%d\n",a,b);

    callbyrefswap(&a,&b,&c);



}
