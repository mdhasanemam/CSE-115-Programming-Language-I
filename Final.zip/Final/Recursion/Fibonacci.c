#include <stdio.h>
int fibo(int n)
{
    if(n==0)
    {
        return n;
    }
    else if(n==1)
    {
        return 1;
    }
    else
    {
        return fibo(n-1)+fibo(n-2);
    }
}

void print(int current,int n)
{
    if(current>n)
    {
        return;
    }
    else
    {
        printf("%d ", fibo(current));
        print(current+1,n);
    }
}

int main()
{
    int n, result;

    scanf("%d",&n);

    result=fibo(n);
    printf("%d\n",result);
    print(0,n);
        return 0;

}


