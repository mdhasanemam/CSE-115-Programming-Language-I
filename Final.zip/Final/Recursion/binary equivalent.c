/*void printBinary(int x);
Description: Prints the binary equivalent of x.
*/
#include <stdio.h>

void printBinary(int x)
{
    if(x==0)
    {
        return;
    }
    printBinary(x/2);
    printf("%d",x%2);
}
int main()
{
    int n;

    scanf("%d",&n);
    if(n==0)
    {
        printf("0");
    }
    else
    {
        printBinary(n);

    }
    return 0;

}
