/*double harmonicSum(int n);
Description: Returns the sum 1+1/2+1/3+…+1/𝑛 .
*/

#include <stdio.h>
double harmonicSum(int n)
{
    if(n==1)
    {
        return 1.0;
    }
    else
    {
        return 1.0/n+harmonicSum(n-1);
    }
}


int main()
{
    int n;
    double result;

    scanf("%d",&n);

    result=harmonicSum(n);
    printf("%f",result);
}

