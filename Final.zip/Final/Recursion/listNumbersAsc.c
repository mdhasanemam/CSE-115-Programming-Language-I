/*void listNumbersAsc(int start, int end);
Description: Outputs the numbers from start to end in ascending order.
*/
#include <stdio.h>

void listNumbersAsc(int start, int end)
{
 if(start>end)
    {
        return;
    }
    printf("%d ",start);
    listNumbersAsc(start+1,end);
}
int main()
{
    int n, n1;

    scanf("%d",&n);
    scanf("%d",&n1);

   listNumbersAsc(n,n1);

}
