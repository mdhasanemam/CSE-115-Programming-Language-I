/*void listNumbersDesc(int start, int end);
Description: Outputs the numbers from start to end in descending order.
*/
#include <stdio.h>

void listNumbersDesc(int start, int end)
{
    if(start>end)
    {
        return;
    }
    printf("%d ",end);
    listNumbersDesc(start,end-1);
}
int main()
{
    int n, n1;

    scanf("%d",&n);
    scanf("%d",&n1);

    listNumbersDesc(n,n1);

}
