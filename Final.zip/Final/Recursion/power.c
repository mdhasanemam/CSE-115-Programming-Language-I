/*int power(int a, int b);
Description: Returns 𝑎^𝑏. The only arithmetic operation that you are allowed to use in this problem is multiplication (*)
*/
#include <stdio.h>
int power (int n , int n1)
{

    if(n1==0)
    {
        return 1;
    }
    else
    {
        return n*power(n,n1-1);
    }
}


int main()
{
    int n,result,n1;

    scanf("%d %d",&n,&n1);

    result=power(n,n1);
    printf("%d",result);
}


