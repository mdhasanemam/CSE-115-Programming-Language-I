/*int mul(int a, int b);
Description: Returns the product of a and b. The only arithmetic operation that you are allowed to use in this problem is addition (+).
*/
#include <stdio.h>
int mul(int n , int n1)
{
    int sum=0;
    if(n1==0)
    {
        return 0;
    }
    else
    {
        return n+ mul(n,n1-1);;
    }
}


int main()
{
    int n,result,n1;

    scanf("%d %d",&n,&n1);

    result=mul(n,n1);
    printf("%d",result);
}


