/*int sum(int n);
Description: Calculates the the sum 1+2+…+𝑛
*/
#include <stdio.h>
int sum(int n)
{
    if(n==0)
    {
        return n;
    }
    else
    {
        return n+sum(n-1);
    }
}


int main()
{
    int n, result;

    scanf("%d",&n);

    result=sum(n);
    printf("%d",result);
}

