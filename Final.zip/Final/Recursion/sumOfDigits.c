/*int sumOfDigits(int x);
Description: Returns the sum of digits of the positive integer x. For example, when called with the parameter 12345, this function returns 15.
*/
#include <stdio.h>
int sumOfDigits(int n)
{
    if(n==0)
    {
        return 0;
    }
    else
    {
        return n%10+sumOfDigits(n/10);
    }
}


int main()
{
    int n,result;

    scanf("%d",&n);

    result=sumOfDigits(n);
    printf("%d",result);
}

