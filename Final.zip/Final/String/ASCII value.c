/*
1.	Write a program that takes one character as input and prints its ASCII value.
2.	Write a program that takes one integer ASCII value as input and prints the corresponding character.
3.	Write a program that takes one character and checks whether it is an uppercase letter.
4.	Write a program that takes one character and checks whether it is a lowercase letter.
5.	Write a program that takes one character and checks whether it is a digit character from '0' to '9'.
6.	Write a program that prints the ASCII values of:
A Z a z 0 9
7.	Write a program to convert an uppercase letter to lowercase using ASCII logic.
8.	Write a program to convert a lowercase letter to uppercase using ASCII logic.

*/
#include<stdio.h>
#include<string.h>
int main()
{
    /*-----1-------*/

    char a='A';
    char a1='a';
    char b='B';
    char b1='b';

    printf("%d,%d, %d,%d\n", a,a1,b,b1);

    /*-----2-------*/

    int n;
    printf("Enter ASCII value: ",n);
    scanf("%d",&n);
    printf("%c\n",n);

    /*-----3-------*//* and
    /*-----4-------*/

    char ch;

    scanf(" %c",&ch);

    if(ch>=65 && ch<=91)
    {
        printf("Uppercase\n");
    }

    else
    {
        printf("Lowercase\n");
    }

    /*-----5-------*/
    char ch1;

    scanf(" %c",&ch1);
    if(ch1>='0'&& ch1<='9')
    {
        printf("Digit\n");
    }
    else
    {
        printf("Character\n");
    }
    /*-----6-------*/
    char ch2;

    scanf(" %c",&ch2);
    printf("%d\n",ch2);

    /*-----7-------*//*and *//*-----8-------*/
    char ch3;
    scanf(" %c",&ch3);

    if(ch3>='a' && ch3<='z')
    {
        ch3=ch3-32;
        printf("%c",ch3);
    }
    else if(ch3>='A' && ch3<='B')
    {
        ch3=ch3+32;
        printf("%c",ch3);
    }


}
