/*Define a structure named Circle to represent a circle with a radius.
Write a C program to calculate the area and perimeter of two circles and display the results.*/
#include<stdio.h>

struct circle
{
    double radius;
};

double area(struct circle c)
{
    return 3.1416*c.radius*c.radius;
}

double perimeter(struct circle c)
{
    return 2*3.1416*c.radius;
}
int main()
{
    struct circle circle[2];

    for(int i=0;i<2;i++)
    {
        printf("Enter the circle %d: ",i+1);
        scanf("%lf",&circle[i].radius);
    }

     for(int i=0;i<2;i++)
    {
        printf("The circle %d area is %lf and the perimeter is %lf. \n",i+1,area(circle[i]),perimeter(circle[i]));

    }

}
