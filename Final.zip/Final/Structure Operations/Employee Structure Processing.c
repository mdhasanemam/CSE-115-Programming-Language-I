/*Create a structure named "Employee" to store employee details such as employee ID, name, and salary.
Write a program to input data for three employees, find the highest salary employee, and display their information.*/

#include<stdio.h>

struct Employee
{
    int employeeId;
    char name[100];
    float salary;
};
int main()
{

    struct Employee Employees[3];

    for(int i=0; i<3; i++)
    {
        printf("Give Employee %d information: ",i+1);
        printf("\nEnter Employee id: ");
        scanf("%d",&Employees[i].employeeId);
        printf("\nEnter name: ");
        scanf("%s",Employees[i].name);
        printf("\nEnter salary: ");
        scanf("%f",&Employees[i].salary);

    }

    for(int i=0; i<3; i++)
    {
        printf("\n Employee %d information: ",i+1);
        printf("%d, %s ,%f",Employees[i].employeeId,Employees[i].name,Employees[i].salary);
    }

    int maxindex=0;
    int minindex=0;

    for(int i=0; i<3; i++)
    {
        if(Employees[i].salary>Employees[maxindex].salary)
        {
            maxindex=i;
        }
        if(Employees[i].salary<Employees[maxindex].salary)
        {
            minindex=i;
        }
    }

    printf("\n Hight priced Book  %d information: ",maxindex+1);
    printf("%d, %s ,%f",Employees[maxindex].employeeId,Employees[maxindex].name,Employees[maxindex].salary);

    printf("\n Lowest priced Book  %d information: ",minindex+1);
    printf("%d, %s ,%f",Employees[minindex].employeeId,Employees[minindex].name,Employees[minindex].salary);

}
