#include<stdio.h>
#include<stdlib.h>

struct student
{
    char name[100];
    int Id;
};

int main()
{
    int n;
    scanf("%d",&n);
    struct student *arr[n];
    for(int i=0;i<n;i++)
    {
        arr[i]= (struct student *)malloc(sizeof(struct student));
    }

    struct student **ptr=arr;

    for(int i=0;i<n;i++)
    {
        printf("student %d \n",i+1);
        printf("name: ");
        scanf("%s",(*(ptr+i))->name);
        printf("Id: ");
        scanf("%d", &(*(ptr+i))->Id);
    }

     for(int i=0;i<n;i++)
    {
        printf("student %d name is %s and id is %d \n", i+1, (*(ptr+i))->name, (*(ptr+i))->Id);

    }
}
