/*Create a structure called "Student" with members name, age, and total marks.
Write a C program to input data for two students, display their information, and find the average of total marks.*/
#include<stdio.h>

struct student
{
    char name[100];
    int age;
    float totalmarks;
};
int main()
{
    struct student student1,student2;

    printf("Give Student One information: ");
    printf("\nEnter name: ");
    scanf("%s",student1.name);
    printf("\nEnter age: ");
    scanf("%d",&student1.age);
    printf("\nEnter total marks: ");
    scanf("%f",&student1.totalmarks);

    printf("\nGive Student two information: ");
    printf("\nEnter name: ");
    scanf("%s",student2.name);
    printf("\nEnter age: ");
    scanf("%d",&student2.age);
    printf("\nEnter totalmarks: ");
    scanf("%f",&student2.totalmarks);

    printf("\nStudent One information: ");
    printf("%s, %d ,%f",student1.name,student1.age,student1.totalmarks);


    printf("\nStudent two information: ");
    printf("%s, %d ,%.2f",student2.name,student2.age,student2.totalmarks);

    float avg=(student1.totalmarks+student2.totalmarks)/2;

    printf("\nThe Average Marks of the students is : %.2f",avg);




}
