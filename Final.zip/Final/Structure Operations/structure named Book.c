/*Create a structure named Book to store book details like title, author, and price.
Write a C program to input details for three books, find the most expensive and the lowest priced books, and display their information.*/
#include<stdio.h>

struct book
{
    char title[100];
    char author[100];
    int price;
};
int main()
{

    struct book books[3];

    for(int i=0; i<3; i++)
    {
        printf("Give %d book information: ",i+1);
        printf("\nEnter title: ");
        scanf("%s",books[i].title);
        printf("\nEnter author: ");
        scanf("%s",books[i].author);
        printf("\nEnter price: ");
        scanf("%d",&books[i].price);

    }

    for(int i=0; i<3; i++)
    {
        printf("\n Book  %d information: ",i+1);
        printf("%s, %s ,%d",books[i].title,books[i].author,books[i].price);
    }

    int maxindex=0;
    int minindex=0;

    for(int i=0; i<3; i++)
    {
        if(books[i].price>books[maxindex].price)
        {
            maxindex=i;
        }
        if(books[i].price<books[minindex].price)
        {
            minindex=i;
        }
    }

    printf("\n Hight priced Book  %d information: ",maxindex+1);
    printf("%s, %s ,%d",books[maxindex].title,books[maxindex].author,books[maxindex].price);

    printf("\n Lowest priced Book  %d information: ",minindex+1);
    printf("%s, %s ,%d",books[minindex].title,books[minindex].author,books[minindex].price);

    /*struct book book1,book2,book3,;

    printf("Give 1st book information: ");
    printf("\nEnter title: ");
    scanf("%s",book1.title);
    printf("\nEnter author: ");
    scanf("%s",book1.author);
    printf("\nEnter price: ");
    scanf("%d",&book1.price);

    printf("Give 2nd book information: ");
    printf("\nEnter title: ");
    scanf("%s",book2.title);
    printf("\nEnter author: ");
    scanf("%s",book2.author);
    printf("\nEnter price: ");
    scanf("%d",&book2.price);

    printf("Give 3rd book information: ");
    printf("\nEnter title: ");
    scanf("%s",book3.title);
    printf("\nEnter author: ");
    scanf("%s",book3.author);
    printf("\nEnter price: ");
    scanf("%d",&book3.price);

    printf("\n 1st book information: ");
    printf("%s, %s ,%d",book1.title,book1.author,book1.price);


    printf("\n 2nd book information: ");
    printf("%s, %s ,%d",book2.title,book2.author,book2.price);

    printf("\n 3rd book information: ");
    printf("%s, %s ,%d",book3.title,book3.author,book3.price);
    */




}
