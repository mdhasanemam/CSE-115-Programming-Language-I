/*
Lets find the value of 𝑁𝐶𝑅, where the values of N and R will be provided by the user.
FYI, 𝑁𝐶𝑅= 𝑛!/(𝑟!×(𝑛−𝑟)!)
*/
#include<stdio.h>

int factorial(int a)
{
    int fact=1;
    for(int i=1; i<=a; i++)
    {
        fact=fact*i;
    }
    return fact;
}
int main()
{
 int n,r;
 printf("Enter N and R");
 scanf("%d %d",&n,&r);

 int result = factorial(n)/(factorial(r)*factorial(n-r));
 printf("%dC%d= %d",n,r,result);
}
