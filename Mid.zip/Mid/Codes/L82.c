#include<stdio.h>
void draw_circle()
{
    printf("   **   \n");
    printf(" *    * \n");
    printf(" *    * \n");
    printf("   **   \n");
}

void draw_rectangle()
{
    printf(" ****** \n");
    printf(" *    * \n");
    printf(" *    * \n");
    printf(" *    * \n");
    printf(" ****** \n");
}
void draw_triangle()
{
    printf("   *    \n");
    printf("  *  *  \n");
    printf(" *    * \n");
    printf("********\n");
}

void draw_intersect_line()
{
    printf("   *    \n");
    printf("  *  *  \n");
    printf(" *    * \n");
    printf("*      *\n");
}

void rocket()
{
    draw_triangle();
    draw_rectangle();
    draw_intersect_line();
}

void male()
{
    draw_circle();
    draw_rectangle();
    draw_intersect_line();
}
void female()
{
    draw_circle();
    draw_triangle();
    draw_intersect_line();
}
int main(void)
{
    rocket();
    printf("\n\n");
    female();
    printf("\n\n");
    male();
    printf("\n\n");
}
