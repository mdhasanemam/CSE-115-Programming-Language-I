/*Say we want to write a function that calculates 𝑎𝑏, where both 𝑎 and 𝑏 are positive integers
*/
#include<stdio.h>
#include<math.h>
void ab(int a,int b);
int result;
int main(void)
{
    ab(5,6);
    printf("%d",result);
}
void ab(int a,int b)
{
     result = pow(a,b);
    //return result;
}
