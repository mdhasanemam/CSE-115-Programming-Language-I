/*Lets find if N is a prime number, where N will be provided by the user
*/
#include<stdio.h>
int primechk(int a)
{
    int i=2;
    while(i<=a/2)
    {
        if(a%i==0)
        {
            return 0;
        }else
        {
            i++;
        }
    }
    return 1;
}
int main()
{
    int n;
    printf("Enter the num; ");
    scanf("%d",&n);

    if(primechk(n))
    {
        printf("The number is prime");

    }
    else
    {
                printf("The number is not prime");

    }
}
