/*Take a number N as input from the user and print this pyramid of asterisk. N is the number of asterisk in the last row (you can assume that N will always be a positive odd number).

    *
   ***
  *****
 *******
*********
*/
#include<stdio.h>
int pyramid (int a)
{
    for(int i=1;i<=a;i++)
    {
        for(int j=1;j<=a-i;j++)
        {
            printf(" ");
        }
        for(int j=1;j<=2*i-1;j++)
        {
            printf("*");
        }
        printf("\n");
    }
}
int main()
{
    int x,y;
    printf("Enter N; ");
    scanf("%d",&x);
    y= pyramid(x);
    //printf("%d",x);
}
