/*/*Take a number N as input from the user and print this diamond of asterisk. N is the number of asterisk in the middle row (you can assume that N will always be a positive even number).

    *
   ***
  *****
 *******
*********
*********
 *******
  *****
   ***
    *
*/
#include<stdio.h>
int pyramid (int a)
{
    for(int i=2;i<=a;i+=2)
    {
        for(int j=1;j<=(a-i)/2;j++)
        {
            printf(" ");
        }
        for(int j=1;j<=i;j++)
        {
            printf("*");
        }
        printf("\n");
    }
}
int pyramid2 (int a)
{
    for(int i=a;i>=2;i-=2)
    {
        for(int j=1;j<=(a-i)/2;j++)
        {
            printf(" ");
        }
        for(int j=1;j<=i;j++)
        {
            printf("*");
        }
        printf("\n");
    }
}
int main()
{
    int x,y;
    printf("Enter N; ");
    scanf("%d",&x);
    y= pyramid(x);
    y= pyramid2(x);

    //printf("%d",x);
}

