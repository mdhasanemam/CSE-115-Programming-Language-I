/*Take a number N as input from the user and print this pyramid of asterisk. N is the number of asterisk in the last row (you can assume that N will always be a positive odd number).

    *
   ***
  *****
 *******
*********

#include<stdio.h>
int pyramid (int a)
{
    for(int i=2;i<=a;i+=2)
    {
        for(int j=1;j<=(a-i)/2;j++)
        {
            printf(" ");
        }
        for(int j=1;j<=i;j++)
        {
            printf("*");
        }
        printf("\n");
    }
}
int main()
{
    int x,y;
    printf("Enter N; ");
    scanf("%d",&x);
    y= pyramid(x);
    //printf("%d",x);
}

*/
#include<stdio.h>

double harmonicSum(int n)
{
    double sum=0.0;
    for(int i=1;i<=n;i++)
    {
        sum=sum+1.0/i;
    }
    return sum;

}
int main()
{
    int a;
    scanf("%d",&a);
    printf("The sum is %f",harmonicSum(a));

}
