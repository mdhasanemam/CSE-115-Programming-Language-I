/*14. Triangle Type Determination

Write a C program to check whether a triangle is Equilateral, Isosceles or Scalene.

Equilateral triangle: An equilateral triangle is a triangle in which all three sides are equal. In the familiar Euclidean geometry, equilateral triangles are also equiangular; that is, all three internal angles are also congruent to each other and are each 60�.

Isosceles triangle: An isosceles triangle is a triangle that has two sides of equal length.

Scalene triangle: A scalene triangle is a triangle that has three unequal sides, such as those illustrated above.*/

#include <stdio.h>

int main(){

int a, b,c;

printf("Enter a,b,c :");
scanf("%d %d %d",&a,&b,&c);

if(a==b && b==c){
    printf("The triangle is Equilateral triangle ");
}else if(a==b || a==c || b==c){
printf("The triangle is Isosceles triangle ");
}else{
printf("The triangle is Scalene triangle ");
}



printf("%d\n", 8 - 5 / 2);

printf("%f\n", 8 - 5.0 / 2);

printf("%d\n", -17 / 4 + 9 / -2);

printf("%d\n", 14 % 5 + 3 * 4);

printf("%d\n", 25 % -6 + -7 * 3);

}


