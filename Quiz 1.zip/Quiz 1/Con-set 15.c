/*15. Triangle Validity by Angles

Write a C program to check whether a triangle can be formed with the given values for the angles.
Test Data :
40 55 65
Expected Output :
The triangle is not valid.

Click me to see the solution*/

#include <stdio.h>
int main(){

float a,b,c,sum;

printf("Enter Three Angles: ");
scanf("%2f %2f %2f",&a,&b,&c);


sum= a+b+c;

if(sum==180){
    printf("The Triangle is Valid");

}else{
printf("The Triangle is not valid");
}

}



