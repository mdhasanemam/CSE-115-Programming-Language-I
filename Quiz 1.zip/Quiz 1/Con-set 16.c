/*16. Character Type Classification

Write a C program to check whether a character is an alphabet, digit or special character.
Test Data :
@
Expected Output :
This is a special character.
*/

#include <stdio.h>

int main(){
char a;

printf("Enter the charracter: ");
scanf("%c",&a);

if((a>='a' && a<='z') || (a>='A' && a<='Z') ){

    printf("This is an cha");
}else if(a>='0' && a<='9'){
   printf("This an digit");

}else{
printf("This an special cha");
}

}
