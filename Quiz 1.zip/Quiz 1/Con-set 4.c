/*4. Leap Year Determination

Write a C program to find whether a given year is a leap year or not.
Test Data : 2016
Expected Output :
2016 is a leap year.*/

#include <stdio.h>

int main(){

int y;

printf("Enter year:");
scanf("%d",&y);

if((y%4 ==0 && y%100 !=0)||(y%400==0)){

    printf("The Year is leap Year");
}else{
printf("The Year is not leap Year");
}




}
