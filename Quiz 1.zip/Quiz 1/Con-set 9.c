/*9. Coordinate Quadrant Identification

Write a C program to accept a coordinate point in an XY coordinate system and determine in which quadrant the coordinate point lies.
Test Data : 7 9
Expected Output :
The coordinate point (7,9) lies in the First quadrant.*/

#include <stdio.h>

int main()
{

    int x,y;

    printf("Enter X AND y");
    scanf("%d %d",&x,&y);

    if(x==0 && y==0)
    {
        printf("The point is in center");
    }
    else if(x>0 && y>00)
    {
        printf("The point is in 1st quadrant");
    }
    else if(x<0 && y>0)
    {
        printf("The point is in 2nd quadrant");
    }
    else if(x<0 && y<0)
    {
        printf("The point is in 3rd quadrant");
    }
    else if(x>0 && y<0)
    {
        printf("The point is in 4th quadrant");
    }
    else if(x==0)
    {
        printf("The point is in x axis");
    }
    else if(y==0)
    {
        printf("The point is in y axis");
    }


    else
    {
        printf("The point is in Invalid");
    }



}
