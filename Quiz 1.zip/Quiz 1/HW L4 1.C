/*
Write a program that calculates the area and the perimeter of a rectangle where the length and the width of the rectangle are provided by the user as inputs.
*/

#include <stdio.h>
 int main(){
  int area;
  int peri;

  int len;
  int width;

  printf("Enter the Length:(In Meter)\n");
  scanf("%i",&len);

  printf("Enter the width:(In Meter)\n");
  scanf("%i",&width);

  area = len *  width;
  peri = 2*(len + width);

  printf("Area and the Perimeter of a rectangle %d sqr m. and %d m.", area, peri);

 }
