/*
Write a program that calculates the area of a triangle where the base and the height of the triangle are provided by the user as inputs.
*/

#include <stdio.h>
 int main(){
  int area;
  //int peri;

  int base;
  int height;

  printf("Enter the Height:(In Meter)\n");
  scanf("%i",&base);

  printf("Enter the Height:(In Meter)\n");
  scanf("%i",&height);

  area = base *  height;
  //peri = 2*(len + width);

  printf("Area of a triangle %d sqr m.", area);

 }
