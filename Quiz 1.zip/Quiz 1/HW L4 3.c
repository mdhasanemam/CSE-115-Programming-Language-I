/*Write a program that calculates the area and the perimeter of a circle where the radius of the circle is provided by the user as input.*/
#include <stdio.h>
#include <math.h>
int main(){

float redius;
float area;
float peri;
//float pai = 3.1416;

printf("Enter The Radius of the Circle:");
scanf("%f", &redius);


area = pow(redius,2)*M_PI;
peri = 2*redius*M_PI;

printf("The Area and the perimeter of the circle is %f sqr.m and %f m",area,peri);


}
