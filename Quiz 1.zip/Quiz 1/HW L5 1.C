/*1. Write a C program that prompts the user to input three integer values and find the greatest and smallest of those three values.*/


#include <stdio.h>
#include <stdint.h>

int main(){

int a,b,c;
int max,min;

printf("Enter Three Integer:");
scanf("%i %i %i", &a,&b,&c);


max = min = a;

if(max < b) max = b;
if(max < c) max =c;

if(min > b) min=b;
if(min > c) min=c;

printf("The Greatest Number is: %d\n",max);

printf("The smallest Number is: %d\n",min);

/*if(a>=b && a>=c){
    printf("The Greatest Number is: %d\n",a);

}
else if(b>=a && b>=c){
    printf("The Greatest Number is: %d\n",b);

}else{
    printf("The Greatest Number is: %d\n",c);

}

if(a<=b && a<=c){
    printf("The Smallest Number is: %d",a);

}
else if(b<=a && b<=c){
    printf("The Smallest Number is: %d",b);

}else{
    printf("The Smallest Number is: %d",c);

}
*/
return 0;

}
