/*2. Write a program that determines a student�s grade. The program will read three scores and determine the grade based on the following rules.
	if the average score is equal to or above 90%, grade = A
	if the average score is between 70% and 89.99%, grade = B
	if the average score is between 50% and 69.99%, grade = C
	if the average score is below 50%, grade = F
*/

#include <stdio.h>

#include <stdio.h>

int main(){

    float s1, s2, s3;
    float average;

    printf("Enter Three Scores: ");
    scanf("%f %f %f", &s1, &s2, &s3);

    average = (s1 + s2 + s3) / 3;

    if(average >= 90){
        printf("The grade of the student is A");
    }
    else if(average >= 70){
        printf("The grade of the student is B");
    }
    else if(average >= 50){
        printf("The grade of the student is C");
    }
    else{
        printf("The grade of the student is F");
    }

    return 0;
}
