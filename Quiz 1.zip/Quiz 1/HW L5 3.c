/* Tax table:
       0.00�14,999.99     base 0.00     rate 15%
       15,000�29,999.99   base 2,250.00 rate 18%
       30,000�49,999.99   base 5,400.00 rate 22%
       50,000�79,999.99   base 11,000.00 rate 27%
       80,000�150,000.00  base 21,600.00 rate 33%
    */

#include <stdio.h>

int main(){

double salary,tax,rate,lower,base;

printf("Enter Your Salary:");
scanf("%lf",&salary);

if(salary<=14999.99 ){
    base =0.0; rate =0.15; lower=0.0;
}
else if(salary<=29999.99 ){
    base =2250.00; rate =0.18; lower=15000.00;

}else if(salary<=49999.99 ){
    base =5400.00 ; rate =0.22; lower=30000.00;
}else if(salary<=79999.99 ){
    base =11000.00; rate =0.27; lower=50000.00;

}else if(salary<=150000.00){
base =21600.00; rate =0.33; lower=80000.00;
}else{
printf("Invalid Salary");
}


tax = base +(salary -lower)*rate;

printf("Salary : %2f, Tax: %2f, Net Amount: %2f", salary,tax,salary-tax);



}
