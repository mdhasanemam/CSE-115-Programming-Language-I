/*4. Determine if a year (provided as input) is a leap-year or not. Rule: A year is a leap year if it is perfectly divisible by four - except for the years which are divisible by 100 but not divisible by 400. for example, both 1996 and 2000 are leap years. But neither 1990 nor 1900 is a leap year.
*/

#include <stdio.h>

int main()
{

    int year;

    printf(" Enter Year:");
    scanf("%i",&year);

    if((year%4==0 && year%100!=0)||(year%400==0))
    {

        printf(" The year %d is leap year",year);
    }
    else
    {
        printf(" The year %d is not leap year",year);

    }



}
