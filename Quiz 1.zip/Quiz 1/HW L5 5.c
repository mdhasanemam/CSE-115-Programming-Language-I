/*5. Write a program to compute the real roots of a quadratic equation of the form 𝑎𝑥^2+𝑏𝑥+𝑐=0, 𝑎≠0. The program should prompt the user to enter the constants 𝑎, 𝑏, 𝑐. The roots are calculated according to the rules:-
	a) If 𝑏^2−4𝑎𝑐 is zero, there is only one root, which is –𝑏/2𝑎.
	b) If (𝑏^2–4𝑎𝑐) is negative, there are no real roots.
	c) For all other cases, the two real roots are (−𝑏±√(𝑏^2−4𝑎𝑐))/2𝑎.
*/

#include <stdio.h>
#include <math.h>

int main(){

double a,b,c,x,y,z;

printf("Enter a,b,c:");
scanf("%lf  %lf  %lf",&a,&b,&c);

if(a==0){
   printf("Invalid Input a can not be zero");
    return 0;
   }
z= pow(b,2)- 4*a*c;

if(z==0){

    printf("The Answer is %2f",-b/(2*a));
}else if(z<0){

printf("There is no real root");

}
else{
    x=(-b+ sqrt(z))/(2*a);
    y=(-b- sqrt(z))/(2*a);
    printf("The Two Real Root are %2f ,%2f",x,y);
}






}
