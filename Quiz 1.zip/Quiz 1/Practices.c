/*#include <stdio.h>
int main(){
    int a = 19, b = 4;
    printf("%d\n", a/b*b + a%b);
    printf("%d\n", a - b * (a/b));
    return 0;
}
#include <stdio.h>
int main(){
    int x = -17;
    printf("%d\n", x/4);
    printf("%d\n", x%4);
    printf("%d\n", (x/4)*4 + (x%4));
    return 0;
}
#include <stdio.h>
int main(){
    double c;
    c = 1/5;
    printf("%.1f\n", c);
    c = 1.0/5;
    printf("%.1f\n", c);
    return 0;
}

#include <stdio.h>
int main(){
    int x = 3;
    x += 5 * 2;
    printf("%d\n", x);
    x %= 4 + 1;
    printf("%d\n", x);
    return 0;
}
*/
/*
#include <stdio.h>
int main(){
    char ch = 'A';
    ch = ch + 5;
    printf("%c\n", ch);
    printf("%d\n", ch);
    return 0;
}*/
/*
#include <stdio.h>
int main(){
    int x = 5;
    printf("%d\n", x++);
    printf("%d\n", ++x);
    printf("%d\n", x--);
    printf("%d\n", x);
    return 0;
}
*/
/*
#include <stdio.h>
int main(){
    int a=4, b=-2, c=0;
    int x = (a > b && b > c || a == b);
    int y = ((a > b) && !(b > c));
    printf("%d\n", x);
    printf("%d\n", y);
    return 0;
}

#include <stdio.h>
int main(){
    int a = 0, b = 10;
    if (a != 0 && (b/a) > 3) printf("YES\n");
    else printf("NO\n");
    return 0;
}
#include <stdio.h>
int main(){
    int x = 5, y = 2;
    if (x > 0)
        if (y > 3) printf("A\n");
        else printf("B\n");
    else
        printf("C\n");
    return 0;
}*/
/*
#include <stdio.h>
int main(){
    int day = 2;
    switch(day){
        case 1: printf("Mon ");
        case 2: printf("Tue ");
        case 3: printf("Wed ");
        default: printf("Done");
    }
    printf("\n");
    return 0;
}

#include <stdio.h>
int main(){
    int meters = 7, feet = 68, inches = 3;
    printf("R:%03d=%04d.%02d\n", meters, feet, inches);
    return 0;
}/*
#include <stdio.h>
int main(){
    int n; char ch;
    scanf("%d", &n);
    scanf(" %c", &ch);
    printf("%d-%c\n", n, ch);
    return 0;
}
*/
/*
#include <stdio.h>
int main(){
    int day = 0;
    switch(day){
        case 0: printf("Sun\n");break;
        case 1: printf("Mon\n"); break;
        default: printf("Err\n");
    }
}*/

/*12) Sort 3 Numbers (no loops, no arrays)

Input: three integers a b c
Output them in ascending order: min mid max
Hard requirement: use only if/else and assignments.

#include <stdio.h>
int main(){

int a,b,c;

printf("Enter a,b,c");
scanf("%d %d %d",&a,&b,&c);
int min,max;

min = max = a;
if(a==b && b==c) {printf("All are equal\n");  return 0;}
if(min>b) min = b;
if(min>c) min = c;
if(max<b) max = b;
if(max<c) max = c;

printf("Max = %d, Mid = %d, Min = %d",max,a+b+c-max-min,min);


}*/

/*8) Electricity Bill (tier + surcharge)

Input: integer units

First 100 units: 5 per unit

Next 200 units (101�300): 6 per unit

Above 300: 7 per unit
Add fixed meter charge 50.
If final bill > 1000 add 10% surcharge.

#include <stdio.h>
int main()
{

    float units,bill,mc=50,surc=0.1;

    printf("Enter Units: ");
    scanf("%f", &units);

    if(units<0)
    {
        printf("Invalid");
    }
    else if(units<=100)
    {
        bill = units*5;
    }
    else if(units>=101 && units<=300)
    {
        bill = 100*5+(units-100)*6;
    }
    else
    {
        bill = 100*5+200*6+(units-300)*7;
    }

    double total = bill+ mc;

    if(bill>1000)
    {
        total=total+total*surc;
        printf("Your total bill is %f ", total);
    }
    else
    {
        printf("Your total bill is %f ", total);
    }
}*/

/*9) Parking Fee (round up hours)

Input: hours minutes

Total time rounds up to next hour if minutes > 0

Fee:

first 1 hour: 50

next 2 hours: 30 per hour

after 3 hours: 20 per hour
*/
#include <stdio.h>

int main() {
    int h, m;
    int totalHours;
    int fee;

    printf("Enter hours and minutes: ");
    scanf("%d %d", &h, &m);

    /* validation */
    if (h < 0 || m < 0 || m > 59) {
        printf("Invalid\n");
        return 0;
    }

    /* round up rule */
    totalHours = h;
    if (m > 0) totalHours = h + 1;

    /* fee calculation */
    if (totalHours <= 0) {
        fee = 0;
    }
    else if (totalHours == 1) {
        fee = 50;
    }
    else if (totalHours <= 3) {
        /* 1st hour 50, next hours (2nd, 3rd) each 30 */
        fee = 50 + (totalHours - 1) * 30;
    }
    else {
        /* 1st hour 50, next 2 hours 30 each, remaining hours 20 each */
        fee = 50 + 2 * 30 + (totalHours - 3) * 20;
    }

    printf("Total Hours Charged: %d\n", totalHours);
    printf("Parking Fee: %d\n", fee);

    return 0;
}






