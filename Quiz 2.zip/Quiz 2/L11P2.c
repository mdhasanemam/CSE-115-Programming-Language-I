/*An array contains N numbers and we want to search any given number within the array.
For example, consider the following array
14  78  5  90  67  32  85
If we want to search 90, the output is �Found�
If we want to search 100, the output is �Not Found�
*/
#include<stdio.h>

int main()
{
    int n;
    printf(" Enter array size: ");
    scanf("%d", &n);

    int arr[n];
    for(int i=0; i<n; i++)
    {
        printf("Enter array[%d]: ",i);
        scanf("%d", &arr[i]);
    }

    int num,found=0;
    printf(" Enter array the number : ");
    scanf("%d", &num);

    for(int i=0; i<n; i++)
    {
        if(num == arr[i])
        {
            found = 1;
            break;
        }

    }

    if(found==1)
    {
        printf("Found");
    }
    else
    {
        printf("Not found");
    }


}
