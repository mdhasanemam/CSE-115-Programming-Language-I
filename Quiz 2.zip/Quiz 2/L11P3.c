/*
An array contains N numbers and we want to sort all the numbers inside the array in ascending/descending order.
For example, consider the following array
25  14  78  5  90  31  32  85
If we want to sort the array in ascending order, then the program�s output is
5  14  25  31  32  78  85 90
*/
#include<stdio.h>

int main()
{
    int n;
    printf(" Enter array size: ");
    scanf("%d", &n);

    int arr[n];
    for(int i=0; i<n; i++)
    {
        printf("Enter array[%d]: ",i);
        scanf("%d", &arr[i]);
    }

    for(int i=0; i<n-1; i++)
    {
        for(int j=0; j<n-1; j++)
        {
            if(arr[j]>arr[j+1])
            {
                int temp = arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
    }
    printf("Array in ascending order: ");
    for(int i=0; i<n; i++)
    {
        printf("%d ",arr[i]);
    }



    for(int i=0; i<n-1; i++)
    {
        for(int j=0; j<n-1; j++)
        {
            if(arr[j]<arr[j+1])
            {
                int temp = arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
    }
    printf("\nArray in descending order: ");
    for(int i=0; i<n; i++)
    {
        printf("%d ",arr[i]);
    }
}

