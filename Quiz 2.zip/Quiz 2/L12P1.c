#include<stdio.h>
#include <string.h>
int main()
{

    char a[]="I love Bangladesh";
    char b[100];
    printf("Enter your string: ");
    gets(b);
    char c[100];
    printf("Enter your string: ");
    gets(c);
    int i=0,len=0,len2=0,j=0,k=0,l=0,len3=0,len4=0;
    while(a[i]!='\0')
    {
        i++;
        len++;
    }

    printf("%s has %d char with speace\n",a,len);

    while(a[j]!='\0')
    {

        if(a[j]!=' ')
        {
            len2++;
        }
        j++;
    }
    printf("\n%s has %d char without speace",a,len2);


    while(b[k]!='\0')
    {
        k++;
        len3++;
    }

    printf("\n%s has %d char with speace\n",b,len3);

    while(b[l]!='\0')
    {

        if(b[l]!=' ')
        {
            len4++;
        }
        l++;
    }
    printf("%s has %d char without speace",b,len4);

    /*------strcmp---*/

    int f = strcmp(b, c);

    if(f == 0)
    {
        printf("\nThe strings are equal.\n");
    }
    else
    {
        printf("\nThe strings are not equal.\n");
    }

    /*------strncmp---*/

    int g = strncmp(b, c,6);

    if(g == 0)
    {
        printf("\nThe strings are equal.\n");
    }
    else
    {
        printf("\nThe strings are not equal.\n");
    }
    /*------strlen()----*/

    int len5 = strlen(a);
    printf("\n%d",len5);

    int len6 = strlen(b);
    printf("\n%d",len6);

    /*------strcpy---*/
    char d[100];
    strcpy(d,c);

    printf("\n%s \n %s ",c,d);

    /*----strncpy---*/
    char e[100];
    strncpy(e,c,4);

    printf("\n%s \n %s ",c,e);

    /*-----sttcat---*/
    strcat(b, ".");

    strcat(b, c);

    printf("\n%s\n",b);
    printf("\n%s\n",c);

    /*-----sttcat---*/
    strcat(b, ".");

    strncat(b,c,6);

    printf("\n%s\n",b);
    printf("\n%s\n",c);




}
