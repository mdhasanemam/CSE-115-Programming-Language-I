#include<stdio.h>

int main()
{
    int r,c,r1,c1;
    printf("Enter Row and Coloum ");
    scanf("%d %d",&r,&c);
    printf("Enter 2nd array Row and Coloum ");
    scanf("%d %d",&r1,&c1);
    int arr[r][c];
    int arr2[r1][c1];
    /*--- Input----*/
    for(int i=0; i<r; i++)
    {
        for(int j=0; j<c; j++)
        {
            printf("Enter [%d][%d]\n",i,j);
            scanf("%d",&arr[i][j]);
            //scanf("%d",&arr2[i][j]);
        }
    }
    /*--- Input----*/
    for(int i=0; i<r1; i++)
    {
        for(int j=0; j<c1; j++)
        {
            printf("Enter 2nd [%d][%d]\n",i,j);
            scanf("%d",&arr2[i][j]);

        }
    }
    /*---output---*/
    printf("2D Array\n");
    for(int i=0; i<r; i++)
    {
        for(int j=0; j<c; j++)
        {
            printf(" %d",arr[i][j]);

        }
        printf("\n");

    }

    /*---output---*/
    printf("2nd 2D Array\n");
    for(int i=0; i<r1; i++)
    {
        for(int j=0; j<c1; j++)
        {

            printf(" %d",arr2[i][j]);

        }
        printf("\n");

    }

    /*-----addition----*/
    int arr3[r][c];
    if(r!=r1 || c!=c1)
    {
        printf("Invalid");
    }
    else
    {
        for(int i=0; i<r; i++)
        {
            for(int j=0; j<c; j++)
            {
                arr3[i][j]=arr[i][j]+arr2[i][j];

            }

        }
        /*----result----*/
        printf("Sum Array\n");
        for(int i=0; i<r; i++)
        {
            for(int j=0; j<c; j++)
            {

                printf(" %d",arr3[i][j]);

            }
            printf("\n");

        }

    }


    /*----multiply---*/
    int arr4[r][c1];
    if(c!=r1)
    {
        printf("Invalid");
    }
    else
    {
        for(int i=0; i<r; i++)
        {

            for(int j=0; j<c1; j++)
            {
                int sum=0;
                for(int k=0; k<c; k++)
                {
                    sum=sum+arr[i][k]*arr2[k][j];
                }
                arr4[i][j]= sum;

            }

        }
        /*----result----*/
    printf("Mul Array\n");
    for(int i=0; i<r; i++)
    {
        for(int j=0; j<c1; j++)
        {

            printf(" %d",arr4[i][j]);

        }
        printf("\n");

    }

    }


}
