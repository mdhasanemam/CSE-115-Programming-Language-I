#include <stdio.h>
#include <string.h>
int main()
{
    int i=0,found;
    char city[4][20]= {"Dhaka","Chittagong",
                       "Rajshahi","Khulna"
                      };

    char str[20];
    printf("Enter city: ");
    gets(str);
    while(i<4)
    {
        if (strcasecmp(str, city[i]) == 0)
        {
            found = 0;
            break;
        }
        i++;
    }

    if(found ==0)
    {
        printf("Found");
    }
    else
    {
        printf("Not Found");

    }
    return 0;
}
